// Generated from POO Flow Scheme. Do not edit.
export type WorkflowStepState = "pending" | "running" | "completed" | "failed";
export type WorkflowStep<Id extends string = string, Kind extends string = string> = {
  readonly id: Id;
  readonly ordinal: number;
  readonly name: string;
  readonly kind: Kind;
  readonly dependencies: readonly string[];
};
export type WorkflowDefinition<Steps extends readonly WorkflowStep[] = readonly WorkflowStep[]> = {
  readonly id: string;
  readonly steps: Steps;
  readonly edges: readonly { readonly source: string; readonly target: string }[];
};

export const workflow = {
  id: "browser-contribution",
  steps: [
    { id: "0-receive-request", ordinal: 0, name: "receive-request", kind: "scheme", dependencies: [] },
    { id: "1-select-profile", ordinal: 1, name: "select-profile", kind: "scheme", dependencies: ["0-receive-request"] },
    { id: "2-compose-policy", ordinal: 2, name: "compose-policy", kind: "scheme", dependencies: ["1-select-profile"] },
    { id: "3-execute-scenario", ordinal: 3, name: "execute-scenario", kind: "scheme", dependencies: ["2-compose-policy"] },
    { id: "4-verify-proof", ordinal: 4, name: "verify-proof", kind: "scheme", dependencies: ["3-execute-scenario"] },
    { id: "5-publish-contribution", ordinal: 5, name: "publish-contribution", kind: "scheme", dependencies: ["4-verify-proof"] },
  ],
  edges: [
    { source: "0-receive-request", target: "1-select-profile" },
    { source: "1-select-profile", target: "2-compose-policy" },
    { source: "2-compose-policy", target: "3-execute-scenario" },
    { source: "3-execute-scenario", target: "4-verify-proof" },
    { source: "4-verify-proof", target: "5-publish-contribution" },
  ],
} as const satisfies WorkflowDefinition;

export type Workflow = typeof workflow;
export type WorkflowStepId = Workflow["steps"][number]["id"];
export type WorkflowStepKind = Workflow["steps"][number]["kind"];

export const workflowTopology = new Uint32Array([
  1, 6, 5,
  0, 1, 2, 3, 4, 5,
  0, 1,
  1, 2,
  2, 3,
  3, 4,
  4, 5,
]);
