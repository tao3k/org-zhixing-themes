// Generated from a POO Flow User Composition. Do not edit.
export type WorkflowNodeKind = "composition" | "case" | "profile-instance";
export type WorkflowStep = { readonly id: string; readonly ordinal: number; readonly name: string; readonly kind: WorkflowNodeKind; readonly dependencies: readonly string[]; readonly parentId?: string; readonly sourceId: string; readonly relation: string; readonly detail: string };
export type WorkflowDefinition = { readonly id: string; readonly rootId: string; readonly steps: readonly WorkflowStep[]; readonly edges: readonly { readonly source: string; readonly target: string; readonly label: string }[] };

export const workflow = {
  id: "browser-profile-composition",
  rootId: "composition:browser-profile-composition",
  steps: [
    { id: "composition:browser-profile-composition", ordinal: 1, name: "browser-profile-composition", kind: "composition", dependencies: [], sourceId: "composition-definition:browser-profile-composition", relation: "root", detail: "User Composition instance" },
    { id: "case:real-scenario", ordinal: 2, name: "real-scenario", kind: "case", dependencies: ["composition:browser-profile-composition"], parentId: "composition:browser-profile-composition", sourceId: "case-definition:real-scenario", relation: "compose", detail: "Reusable Case instance" },
    { id: "case:real-scenario/research-case", ordinal: 3, name: "research-case", kind: "case", dependencies: ["case:real-scenario"], parentId: "case:real-scenario", sourceId: "case-definition:research-case", relation: "step", detail: "Reusable Case instance" },
    { id: "profile:real-scenario/research-case/researcher", ordinal: 4, name: "researcher", kind: "profile-instance", dependencies: ["case:real-scenario/research-case"], parentId: "case:real-scenario/research-case", sourceId: "profile:research/researcher", relation: "step", detail: "Profile instance" },
    { id: "profile:real-scenario/research-case/evidence-curator", ordinal: 5, name: "evidence-curator", kind: "profile-instance", dependencies: ["case:real-scenario/research-case"], parentId: "case:real-scenario/research-case", sourceId: "profile:research/evidence-curator", relation: "step", detail: "Profile instance" },
    { id: "case:real-scenario/qualification-case", ordinal: 6, name: "qualification-case", kind: "case", dependencies: ["case:real-scenario"], parentId: "case:real-scenario", sourceId: "case-definition:qualification-case", relation: "step", detail: "Reusable Case instance" },
    { id: "profile:real-scenario/qualification-case/evidence-curator", ordinal: 7, name: "evidence-curator", kind: "profile-instance", dependencies: ["case:real-scenario/qualification-case"], parentId: "case:real-scenario/qualification-case", sourceId: "profile:research/evidence-curator", relation: "step", detail: "Profile instance" },
    { id: "profile:real-scenario/runtime", ordinal: 8, name: "runtime", kind: "profile-instance", dependencies: ["case:real-scenario"], parentId: "case:real-scenario", sourceId: "profile:research/runtime", relation: "handoff", detail: "Profile instance" },
  ],
  edges: [
    { source: "composition:browser-profile-composition", target: "case:real-scenario", label: "compose" },
    { source: "case:real-scenario", target: "case:real-scenario/research-case", label: "step" },
    { source: "case:real-scenario/research-case", target: "profile:real-scenario/research-case/researcher", label: "step" },
    { source: "case:real-scenario/research-case", target: "profile:real-scenario/research-case/evidence-curator", label: "step" },
    { source: "case:real-scenario", target: "case:real-scenario/qualification-case", label: "step" },
    { source: "case:real-scenario/qualification-case", target: "profile:real-scenario/qualification-case/evidence-curator", label: "step" },
    { source: "case:real-scenario", target: "profile:real-scenario/runtime", label: "handoff" },
  ],
} as const satisfies WorkflowDefinition;

export const workflowTopology = new Uint32Array([1, 8, 7]);
